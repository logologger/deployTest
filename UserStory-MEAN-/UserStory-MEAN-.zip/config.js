module.exports={

	"database":"mongodb://localhost/rajat",
	"port":process.env.PORT || 3000,
	"secretKey":"YourSecretKey"



}

